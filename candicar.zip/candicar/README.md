# CandiCar

Prototype web — mise en relation moniteurs d'auto-ecole / candidats libres.
HTML + Tailwind (build) + JavaScript vanilla. Donnees de demo dans `js/data.js`.

## Lancer le projet

1. Installer les dependances (une seule fois) :
   ```
   npm install
   ```

2. Generer le CSS :
   ```
   npm run build      # build optimise (genere dist/output.css)
   npm run dev        # mode watch pendant le developpement
   ```

3. Ouvrir `index.html` dans le navigateur.

> `index.html` charge `./dist/output.css`. Il faut donc avoir lance `build`
> (ou `dev`) au moins une fois, sinon la page s'affiche sans style.

## Mettre en ligne (GitHub Pages)

Commiter : `index.html`, le dossier `js/`, et `dist/output.css` (genere).
Activer Pages sur la branche, racine du repo. C'est tout — aucun build cote serveur.

## Structure

- `index.html` ........ structure (8 ecrans, menu, chatbot)
- `src/input.css` ..... directives @tailwind + CSS custom (voiture, glow, animations)
- `dist/output.css` ... CSS compile (genere — ne pas editer a la main)
- `js/data.js` ........ donnees de demo (moniteurs, FAQ) -> futur Supabase
- `js/app.js` ......... logique (navigation, menu, chatbot, calendrier, rendu)
- `tailwind.config.js`  couleurs + polices du theme

## Etape suivante : Supabase

Remplacer les tableaux de `js/data.js` par des appels :
```js
const { data: moniteurs } = await supabase.from('moniteurs').select();
```
en gardant la meme structure d'objet -> rien a changer cote affichage.
